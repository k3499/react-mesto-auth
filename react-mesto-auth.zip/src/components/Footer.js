
function Footer() {
  return (
    <footer className="footer">
      <p className="footer__copy">&copy; 2021 Mesto Russia</p>
    </footer>
  );
  }

export default Footer;
